Void Loop ( ) {
// kode program
}