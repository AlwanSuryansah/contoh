boolean val = false ;
boolean state = true ;