Void setup () {

}

Void loop () {
   int a , b ;
   int c ; Local variable declaration
   a = 0;
   b = 0; actual initialization
   c = 10;
}