Char chr_r = ‘r’
Char chr_e = 97 ;